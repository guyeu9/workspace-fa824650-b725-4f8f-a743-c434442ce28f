'use client'

import React, { useEffect, useRef, useState } from 'react'

export default function Home() {
  const [showWelcome, setShowWelcome] = useState(true)
  const [outputHistory, setOutputHistory] = useState<Array<{ type: 'user' | 'system' | 'room-name' | 'room-desc' | 'choices-data', content: string; className?: string }>>([])
  const [choices, setChoices] = useState<any[]>([])
  const [inventory, setInventory] = useState<string[]>([])
  const [isProcessing, setIsProcessing] = useState(false)
  const [currentScene, setCurrentScene] = useState<any>(null)
  const outputRef = useRef<HTMLDivElement>(null)

  const storyData = {
    start: 'foyer',
    scenes: {
      foyer: {
        id: 'foyer',
        name: 'The Foyer',
        desc: '**欢迎使用 TEXT ENGINE 演示光盘！**\n\n这张光盘是一个文本冒险游戏，旨在介绍 text engine 中可用的功能。\n\n输入 **LOOK** 查看四周。',
        img: '',
        exits: [
          { dir: 'north', id: 'reception' }
        ],
        items: [
          { name: 'tall window', desc: '你只能看到蓬松的白云在蓝天上。' }
        ]
      },
      reception: {
        id: 'reception',
        name: 'Reception Desk',
        desc: '**BENJI** 在这里。我确信他很高兴告诉你关于 text engine 中可用的功能。\n\n*你可以使用 **TALK** 命令与角色交谈。\n\n向 **EAST** 是一扇关闭的 **DOOR**。\n\n向 **SOUTH** 是你开始冒险的大厅。\n\n在 **DESK** 旁边是通往 **UP** 的 **STAIRS**。',
        exits: [
          { dir: 'east', id: 'lab' },
          { dir: 'south', id: 'foyer' }
        ],
        items: [
          { name: 'desk' },
          { name: 'door', desc: '门上有 4 英寸的金属字母钉着。它们拼写为："RESEARCH LAB".' }
        ]
      },
      lab: {
        id: 'lab',
        name: 'Research Lab',
        desc: '有一个 **蓝色机器人** 静静悬浮在白色虚空的中央。它们似乎在等待指示。（输入 **TALK** 与机器人交谈。）',
        exits: [
          { dir: 'west', id: 'reception' }
        ],
        items: []
      }
    }
  }

  const renderMarkdown = (text: string) => {
    let html = text
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    html = html.replace(/\*(.*?)\*/g, '<em>$1</em>')
    html = html.replace(/~~(.*?)~~/g, '<del>$1</del>')
    html = html.replace(/`(.*?)`/g, '<code>$1</code>')
    html = html.replace(/\n/g, '<br/>')
    return html
  }

  const executeCommand = (cmd: string) => {
    setOutputHistory(prev => [...prev, { type: 'user', content: `> ${cmd}` }])

    switch (cmd.toLowerCase()) {
      case 'look':
        if (currentScene) {
          setOutputHistory(prev => [...prev, { type: 'room-name', content: currentScene.name, className: 'room-name' }])
          setOutputHistory(prev => [...prev, { type: 'room-desc', content: currentScene.desc }])
        }
        break

      case 'items':
        if (currentScene && currentScene.items) {
          const items = currentScene.items
            .map((item: any) => item.desc ? `${item.name}: ${item.desc}` : item.name)
            .join('\n')
          setOutputHistory(prev => [...prev, { type: 'system', content: `你看到：\n${items}` }])
        }
        break

      case 'inv':
      case 'inventory':
        if (inventory.length === 0) {
          setOutputHistory(prev => [...prev, { type: 'system', content: '你的背包是空的。' }])
        } else {
          const items = inventory.map(i => `  • ${i}`).join('\n')
          setOutputHistory(prev => [...prev, { type: 'system', content: `你的背包：\n${items}` }])
        }
        break

      case 'help':
        setOutputHistory(prev => [...prev, { type: 'system', content: '可用命令：\n  LOOK - 观察四周\n  ITEMS - 列出房间内的物品\n  INV - 检查你的背包\n  HELP - 显示此帮助消息' }])
        break

      case 'save':
        setOutputHistory(prev => [...prev, { type: 'system', content: '游戏已保存！' }])
        break

      case 'load':
        setOutputHistory(prev => [...prev, { type: 'system', content: '游戏已加载！' }])
        break

      case 'clear':
        setOutputHistory(prev => [])
        break

      default:
        const dirMap: Record<string, string> = {
          'n': 'north', 's': 'south', 'e': 'east', 'w': 'west',
          'north': 'north', 'south': 'south', 'east': 'east', 'west': 'west'
        }

        let matchedDir = null
        const commandLower = cmd.toLowerCase()

        for (const [key, dir] of Object.entries(dirMap)) {
          if (commandLower === key || commandLower.startsWith(key + ' ')) {
            matchedDir = dir
            break
          }
        }

        if (matchedDir) {
          if (currentScene && currentScene.exits) {
            const exit = currentScene.exits.find((e: any) => e.dir === matchedDir)
            if (exit) {
              const choiceText = `> ${matchedDir.toUpperCase()} -> ${exit.id}`
              setOutputHistory(prev => [...prev, { type: 'user-choice', content: choiceText }])
              moveToScene(exit.id, `${matchedDir.toUpperCase()} -> ${exit.id}`)
            } else {
              setOutputHistory(prev => [...prev, { type: 'system', content: `向 ${matchedDir} 没有出口。` }])
            }
          }
        } else {
          setOutputHistory(prev => [...prev, { type: 'system', content: `未知命令：${cmd}。输入 HELP 查看可用命令。` }])
        }
    }
  }

  const moveToScene = (sceneId: string, command: string) => {
    const newScene = storyData.scenes[sceneId]
    if (!newScene) {
      setOutputHistory(prev => [...prev, { type: 'system', content: '那个出口似乎通向任何地方。' }])
      return
    }

    setCurrentScene(newScene)
    setChoices(newScene.exits || [])

    setOutputHistory(prev => [...prev,
      { type: 'room-name', content: newScene.name, className: 'room-name' },
      ...(newScene.img ? [{ type: 'img', content: newScene.img }] : []),
      { type: 'room-desc', content: newScene.desc }
    ])

    setInventory(prev => [...prev, ...(newScene.items || []).map((i: any) => i.name)])
  }

  useEffect(() => {
    if (outputHistory.length > 0) {
      window.scrollTo({
        top: document.body.scrollHeight,
        behavior: 'smooth'
      })
    }
  }, [outputHistory])

  return (
    <div style={{
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    }}>
      {showWelcome && (
        <div style={{
          position: 'absolute',
          inset: 0,
          background: 'white',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'flex-start',
          textAlign: 'center',
          padding: '20px',
          zIndex: 100,
          lineHeight: '1.8',
          fontSize: '1.4rem',
          overflowY: 'auto',
          paddingTop: '60px'
        }}>
          <h1 style={{
            fontSize: '2.8rem',
            marginBottom: '25px',
            color: '#6366f1',
            background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            fontWeight: 800,
            textAlign: 'center',
            letterSpacing: '1px',
            textTransform: 'uppercase'
          }}>
            文本引擎
          </h1>
          <p style={{ maxWidth: '600px', color: '#1e293b', margin: '10px 0', fontSize: '1.2rem' }}>
            使用这个引擎，<br />你可以制作自己的文字游戏。
          </p>
          <p style={{ marginTop: '30px', fontSize: '1.1rem', color: '#64748b' }}>
            输入 <strong>LOOK</strong> 查看四周。
          </p>

          <div style={{ marginTop: '30px', marginBottom: '30px', width: '100%', maxWidth: '480px', margin: '30px auto' }}>
            <button
              id="start-btn"
              className="start-main"
              onClick={() => {
                setShowWelcome(false)
                setOutputHistory([])
                const initialScene = storyData.scenes[storyData.start]
                setCurrentScene(initialScene)
                setChoices(initialScene.exits || [])
                setOutputHistory(prev => [...prev,
                  { type: 'room-name', content: initialScene.name, className: 'room-name' },
                  { type: 'room-desc', content: initialScene.desc }
                ])
              }}
              style={{
                padding: '28px 64px',
                fontSize: '1.8rem',
                fontWeight: 800,
                background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
                color: 'white',
                border: 'none',
                borderRadius: '12px',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                boxShadow: '0 20px 25px -5px rgb(99 102 241 / 0.35)',
                width: '100%',
                letterSpacing: '1px',
                textTransform: 'uppercase',
                position: 'relative',
                overflow: 'hidden',
                animation: 'mainButtonGlow 3s ease-in-out infinite',
                minHeight: '60px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              开始游戏
            </button>
          </div>

          <div style={{ display: 'flex', gap: '12px', justifyContent: 'center', flexWrap: 'wrap', marginBottom: '20px' }}>
            <button
              onClick={() => {
                const data = JSON.stringify(storyData, null, 2)
                const blob = new Blob([data], { type: 'application/json' })
                const url = URL.createObjectURL(blob)
                const a = document.createElement('a')
                a.href = url
                a.download = 'example-story.json'
                a.click()
                URL.revokeObjectURL(url)
              }}
              style={{
                marginTop: '60px',
                padding: '10px 20px',
                fontSize: '0.9rem',
                background: 'transparent',
                color: '#64748b',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                boxShadow: '0 1px 2px 0 rgb(0 0 0 / 0.05)',
                fontWeight: 500,
                letterSpacing: '0.3px'
              }}
            >
              示例JSON
            </button>
            <button
              onClick={() => window.open('JSON-GUIDE.html', '_blank')}
              style={{
                marginTop: '60px',
                padding: '10px 20px',
                fontSize: '0.9rem',
                background: 'transparent',
                color: '#64748b',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                boxShadow: '0 1px 2px 0 rgb(0 0 0 / 0.05)',
                fontWeight: 500,
                letterSpacing: '0.3px'
              }}
            >
              星际探索
            </button>
            <button
              onClick={() => window.open('USER-GUIDE.html', '_blank')}
              style={{
                marginTop: '60px',
                padding: '10px 20px',
                fontSize: '0.9rem',
                background: 'transparent',
                color: '#64748b',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                boxShadow: '0 1px 2px 0 rgb(0 0 0 / 0.05)',
                fontWeight: 500,
                letterSpacing: '0.3px'
              }}
            >
              用户指南
            </button>
          </div>

          <div style={{ marginTop: '35px', padding: '20px', background: 'rgba(99, 102, 241, 0.06)', borderRadius: '12px', borderLeft: '4px solid #6366f1', backdropFilter: 'blur(10px)' }}>
            <h3 style={{ marginBottom: '15px', color: '#6366f1', fontSize: '1.2rem' }}>快速开始指南</h3>
            <div style={{ textAlign: 'left', maxWidth: '500px', margin: '0 auto', fontSize: '0.95rem', lineHeight: '1.7' }}>
              <p><strong>1. 开始游戏：</strong>点击主按钮，立即开始冒险</p>
              <p><strong>2. 探索世界：</strong>使用 <code>LOOK</code> 查看，<code>GO 北</code> 移动</p>
              <p><strong>3. 互动操作：</strong><code>TAKE 饥匙</code> 拾取，<code>USE 物品</code> 使用</p>
              <p><strong>4. 对话系统：</strong><code>TALK TO 角色名</code> 与NPC交流</p>
              <p><strong>5. 自定义故事：</strong>下载示例JSON → 修改 → 导入 → 开始冒险！</p>
            </div>
          </div>

          <div style={{ marginTop: '20px', padding: '16px', background: 'rgba(52, 211, 153, 0.08)', borderRadius: '12px', borderLeft: '4px solid #34d399', fontSize: '0.9rem', lineHeight: '1.5' }}>
            <strong style={{ display: 'block', marginBottom: '12px', color: '#34d399' }}>相关资源</strong>
            <div style={{ display: 'flex', gap: '20px', justifyContent: 'center', flexWrap: 'wrap', marginTop: '15px' }}>
              <span style={{ fontSize: '0.9rem', color: '#64748b' }}>
                <a href="/JSON-GUIDE.html" target="_blank" style={{ color: '#6366f1', textDecoration: 'none', fontWeight: '500', transition: 'all 0.2s ease' }}>JSON格式说明</a>
              </span>
              <span style={{ fontSize: '0.9rem', color: '#64748b' }}>
                <a href="/USER-GUIDE.html" target="_blank" style={{ color: '#6366f1', textDecoration: 'none', fontWeight: '500', transition: 'all 0.2s ease' }}>完整使用说明</a>
              </span>
              <span style={{ fontSize: '0.9rem', color: '#64748b' }}>
                <a href="/json-validator.html" target="_blank" style={{ color: '#6366f1', textDecoration: 'none', fontWeight: '500', transition: 'all 0.2s ease' }}>JSON验证器</a>
              </span>
              <span style={{ fontSize: '0.9rem', color: '#64748b' }}>
                <a href="/JSON-STORY-GUIDE.html" target="_blank" style={{ color: '#6366f1', textDecoration: 'none', fontWeight: '500', transition: 'all 0.2s ease' }}>故事创作指南</a>
              </span>
            </div>
          </div>
        </div>
      )}

      {!showWelcome && (
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          minHeight: '100vh',
          maxWidth: '1200px',
          margin: '0 auto',
          width: '100%',
          position: 'relative',
          isolation: 'isolate',
          overflow: 'hidden',
          flexShrink: 1,
          flexGrow: 1,
          alignItems: 'stretch',
          justifyContent: 'flex-start',
          background: '#f5f7fa'
        }}>
          <div style={{
            position: 'relative',
            width: '100%',
            flexShrink: 0,
            background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
            color: 'white',
            padding: '20px 24px',
            textAlign: 'center',
            boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between'
          }}>
            <h1 style={{ margin: 0, fontSize: '1.8rem', fontWeight: 700, flex: 1, textAlign: 'center' }}>
              文本引擎 - 融合版
            </h1>
            <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
              <a
                href="https://simplefeedback.app/feedback/nDf7Lhk7Ohnw"
                target="_blank"
                style={{
                  display: 'inline-block',
                  marginTop: '12px',
                  padding: '8px 16px',
                  background: 'rgba(255,255,255,0.2)',
                  color: 'white',
                  textDecoration: 'none',
                  borderRadius: '6px',
                  fontSize: '14px',
                  backdropFilter: 'blur(10px)',
                  transition: 'all 0.3s ease'
                }}
              >
                反馈
              </a>
              <button
                onClick={() => {
                  setShowWelcome(true)
                  setOutputHistory([])
                  setCurrentScene(null)
                  setChoices([])
                }}
                style={{
                  padding: '8px 16px',
                  background: 'rgba(255,255,255,0.2)',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  fontSize: '14px',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease'
                }}
              >
                返回主菜单
              </button>
            </div>
          </div>

          <div style={{
            order: 1,
            position: 'relative',
            width: '100%',
            flexShrink: 1,
            zIndex: 1,
            overflowY: 'auto',
            padding: '20px',
            background: 'white',
            lineHeight: '1.7',
            fontSize: '1.15rem',
            color: '#1e293b'
          }}>
            <div ref={outputRef} style={{ minHeight: '200px' }}>
              {outputHistory.map((item, index) => {
                switch (item.type) {
                  case 'img':
                    return (
                      <div key={index} style={{ fontFamily: 'monospace', whiteSpace: 'pre', margin: '10px 0', fontSize: '0.9rem', background: '#f8f9fa', padding: '15px', borderRadius: '8px' }}>
                        {item.content}
                      </div>
                    )

                  case 'room-name':
                    return (
                      <div key={index} style={{
                        margin: item.className === 'room-name' ? '20px 0 15px 0' : '20px 0 5px 0',
                        fontSize: item.className === 'room-name' ? '1.5rem' : '1.2rem',
                        fontWeight: item.className === 'room-name' ? '700' : '600',
                        color: item.className === 'room-name' ? '#6366f1' : '#1e293b',
                        padding: item.className === 'room-name' ? '15px 20px' : '8px 16px',
                        background: item.className === 'room-name' ? 'linear-gradient(135deg, rgba(99, 102, 241, 0.1) 0%, rgba(99, 102, 241, 0.05) 100%)' : 'transparent',
                        borderRadius: item.className === 'room-name' ? '12px' : '8px',
                        borderLeft: item.className === 'room-name' ? '4px solid #6366f1' : 'none',
                        boxShadow: item.className === 'room-name' ? '0 2px 8px rgba(99, 102, 241, 0.1)' : 'none'
                      }}>
                        {item.content}
                      </div>
                    )

                  case 'room-desc':
                    return (
                      <div key={index} style={{
                        margin: '10px 0',
                        padding: '10px',
                        lineHeight: '1.6',
                        color: '#374151'
                      }}>
                        <div dangerouslySetInnerHTML={{ __html: renderMarkdown(item.content) }} />
                      </div>
                    )

                  case 'user':
                    return (
                      <div key={index} style={{
                        margin: '4px 0',
                        padding: '8px 12px',
                        borderRadius: '8px',
                        backgroundColor: '#f0f9ff',
                        fontSize: '1rem',
                        color: '#6366f1'
                      }}>
                        {item.content}
                      </div>
                    )

                  case 'system':
                    return (
                      <div key={index} style={{
                        margin: '4px 0',
                        padding: '8px 12px',
                        borderRadius: '8px',
                        backgroundColor: 'transparent',
                        fontSize: '1rem',
                        color: '#1e293b'
                      }}>
                        <div dangerouslySetInnerHTML={{ __html: renderMarkdown(item.content) }} />
                      </div>
                    )

                  case 'user-choice':
                    return (
                      <div key={index} style={{
                        margin: '4px 0',
                        padding: '8px 12px',
                        borderRadius: '8px',
                        backgroundColor: '#f0fdf4',
                        fontSize: '1rem',
                        color: '#059669',
                        fontWeight: '500',
                        borderLeft: '4px solid #059669'
                      }}>
                        {item.content}
                      </div>
                    )

                  case 'choices-data':
                    return null

                  default:
                    return (
                      <div key={index} style={{
                        margin: '4px 0',
                        padding: '8px 12px',
                        borderRadius: '8px',
                        backgroundColor: 'transparent',
                        fontSize: '1rem',
                        color: '#1e293b'
                      }}>
                        {item.content}
                      </div>
                    )
                }
              })}
            </div>
          </div>

          <div style={{
            order: 2,
            position: 'relative',
            width: '100%',
            flexShrink: 0,
            zIndex: 2,
            padding: '20px',
            background: '#f8f9fa',
            borderTop: '1px solid #e2e8f0',
            flexShrink: 0
          }}>
            <strong style={{ display: 'block', marginBottom: '16px', color: '#6366f1', fontSize: '0.9rem', textAlign: 'center' }}>
              选择选项 / Available Choices:
            </strong>
            <div style={{
              display: 'flex',
              flexDirection: 'row',
              flexWrap: 'wrap',
              gap: '12px',
              justifyContent: 'center'
            }}>
              {choices.length > 0 ? (
                choices.map((choice: any, idx) => {
                  const directionName = choice.dir ? choice.dir.toUpperCase() : choice.id
                    return (
                      <button
                        key={idx}
                        onClick={() => {
                          setIsProcessing(true)
                          const choiceText = `> ${directionName} -> ${choice.id}`
                          setOutputHistory(prev => [...prev, { type: 'user-choice', content: choiceText }])
                          
                          setTimeout(() => {
                            setIsProcessing(false)
                            moveToScene(choice.id, `${directionName} -> ${choice.id}`)
                          }, 500)
                        }}
                        disabled={isProcessing}
                        style={{
                          padding: '14px 24px',
                          background: '#6366f1',
                          color: 'white',
                          border: '2px solid #5558e3',
                          borderRadius: '8px',
                          fontSize: '1rem',
                          fontWeight: '500',
                          cursor: isProcessing ? 'not-allowed' : 'pointer',
                          transition: 'all 0.2s ease',
                          textAlign: 'left',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '10px',
                          width: 'auto',
                          minWidth: '200px',
                          boxSizing: 'border-box'
                        }}
                      >
                        {directionName}
                        {choice.id && <span style={{ fontSize: '0.85rem', opacity: 0.9, marginLeft: '8px' }}> - {choice.id}</span>}
                      </button>
                    )
                })
              ) : (
                <p style={{ fontSize: '0.9rem', color: '#64748b', fontStyle: 'italic', textAlign: 'center' }}>
                  暂无可用选择 / No choices available.
                </p>
              )}
            </div>
          </div>

          <div style={{
            order: 3,
            position: 'relative',
            width: '100%',
            flexShrink: 0,
            zIndex: 3,
            padding: '12px 20px',
            background: 'white',
            borderTop: '1px solid #e2e8f0',
            borderBottom: '1px solid #e2e8f0'
          }}>
            <strong style={{ display: 'block', marginBottom: '16px', color: '#6366f1', fontSize: '0.9rem', textAlign: 'center' }}>
              快捷操作 / Quick Actions:
            </strong>
            
            <div className="fixed-buttons-row" style={{
              display: 'flex',
              gap: '8px',
              width: '100%',
              alignItems: 'center'
            }}>
              <button onClick={() => executeCommand('look')} style={{
                padding: '10px 20px',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                background: 'white',
                color: '#64748b',
                fontSize: '14px',
                fontWeight: '500',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '4px',
                boxSizing: 'border-box'
              }}>
                观察
              </button>
              <button onClick={() => executeCommand('items')} style={{
                padding: '10px 20px',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                background: 'white',
                color: '#64748b',
                fontSize: '14px',
                fontWeight: '500',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '4px',
                boxSizing: 'border-box'
              }}>
                物品
              </button>
              <button onClick={() => executeCommand('inv')} style={{
                padding: '10px 20px',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                background: 'white',
                color: '#64748b',
                fontSize: '14px',
                fontWeight: '500',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '4px',
                boxSizing: 'border-box'
              }}>
                背包
              </button>
              <button onClick={() => executeCommand('help')} style={{
                padding: '10px 20px',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                background: 'white',
                color: '#64748b',
                fontSize: '14px',
                fontWeight: '500',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '4px',
                boxSizing: 'border-box'
              }}>
                帮助
              </button>
              <button onClick={() => executeCommand('save')} style={{
                padding: '10px 20px',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                background: 'white',
                color: '#64748b',
                fontSize: '14px',
                fontWeight: '500',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '4px',
                boxSizing: 'border-box'
              }}>
                保存
              </button>
              <button onClick={() => executeCommand('load')} style={{
                padding: '10px 20px',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                background: 'white',
                color: '#64748b',
                fontSize: '14px',
                fontWeight: '500',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '4px',
                boxSizing: 'border-box'
              }}>
                读取
              </button>
              <button onClick={() => executeCommand('clear')} style={{
                padding: '10px 20px',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                background: 'white',
                color: '#64748b',
                fontSize: '14px',
                fontWeight: '500',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '4px',
                boxSizing: 'border-box'
              }}>
                清除
              </button>
              <button onClick={() => window.open('USER-GUIDE.html', '_blank')} style={{
                padding: '10px 20px',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                background: 'white',
                color: '#64748b',
                fontSize: '14px',
                fontWeight: '500',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '4px',
                boxSizing: 'border-box'
              }}>
                指南
              </button>
            </div>
          </div>

          <div style={{
            order: 4,
            position: 'relative',
            width: '100%',
            flexShrink: 0,
            zIndex: 4,
            padding: '16px 20px',
            background: 'white',
            borderTop: '1px solid #e2e8f0',
            display: 'flex',
            gap: '12px',
            flexWrap: 'wrap',
            justifyContent: 'center',
            boxShadow: '0 -2px 8px -2px rgb(0 0 0 / 0.1)'
          }}>
            <input
              id="input"
              type="text"
              placeholder="输入命令..."
              autoComplete="off"
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  const input = e.currentTarget.value.trim()
                  if (input) {
                    executeCommand(input)
                    e.currentTarget.value = ''
                  }
                }
              }}
              style={{
                flex: 1,
                minWidth: '200px',
                maxWidth: '600px',
                padding: '14px 18px',
                border: '2px solid #e2e8f0',
                borderRadius: '8px',
                fontSize: '1.15rem',
                outline: 'none',
                transition: 'border-color 0.2s ease'
              }}
            />

            <button onClick={() => {
              const input = document.getElementById('input') as HTMLInputElement
              if (input.value.trim()) {
                executeCommand(input.value.trim())
                input.value = ''
              }
            }} style={{
              padding: '14px 24px',
              background: '#6366f1',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '1.1rem',
              minWidth: '110px',
              fontWeight: 600,
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              boxShadow: '0 2px 8px rgba(0 0 0 / 0.1)'
            }}>
              发送
            </button>

            <button onClick={() => {
              const data = {
                scene: currentScene?.id,
                inventory: inventory,
                history: outputHistory,
                timestamp: new Date().toISOString()
              }
              const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
              const url = URL.createObjectURL(blob)
              const a = document.createElement('a')
              a.href = url
              a.download = 'game-save.json'
              a.click()
              URL.revokeObjectURL(url)
            }} style={{
              padding: '14px 24px',
              background: 'transparent',
              color: '#64748b',
              border: '1px solid #e2e8f0',
              borderRadius: '8px',
              fontSize: '1.1rem',
              fontWeight: '500',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              boxShadow: '0 1px 2px 0 rgb(0 0 0 / 0.05)'
            }}>
              导出JSON
            </button>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', position: 'relative' }}>
              <label style={{
                padding: '14px 24px',
                background: 'transparent',
                color: '#64748b',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                fontSize: '1.1rem',
                fontWeight: '500',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                boxShadow: '0 1px 2px 0 rgb(0 0 0 / 0.05)',
                textAlign: 'center',
                display: 'block'
              }}>
                导入JSON
              </label>
              <input
                type="file"
                accept=".json,application/json"
                onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                  const file = event.target.files?.[0]
                  if (!file) return

                  const reader = new FileReader()
                  reader.onload = (e) => {
                    try {
                      const data = JSON.parse(e.target?.result as string)
                      setOutputHistory(prev => [...prev, { type: 'system', content: '游戏导入成功！' }])
                    } catch (error) {
                      setOutputHistory(prev => [...prev, { type: 'system', content: '游戏导入失败：无效的 JSON' }])
                    }
                  }
                  reader.readAsText(file)
                }}
                style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  width: '100%',
                  height: '100%',
                  opacity: 0,
                  cursor: 'pointer'
                }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
