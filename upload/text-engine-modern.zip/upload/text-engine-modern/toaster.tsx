'use client'

import { Toaster as SonnerToaster } from "@/components/ui/toaster";

export function Toaster() {
  return <SonnerToaster />
}
